import { Equipo } from "./Equipo.js";
export class Aula {
    #numero;
    #equipos = [Equipo];
    #puestos;
    constructor(numero, filas, columnas) {
        this.#numero = numero;
        for (let i = 0; i < filas; i++) {
            this.#equipos[i] = Array(columnas).fill(null);
        }
        this.#puestos = filas * columnas;
    }
    activaEquipo(equipo, fila, columna) {
        if (this.#equipos.length > fila) {
            this.#equipos[fila][columna] = equipo;
            console.log(this.#equipos[fila][columna]);
            return true;
        }else{
            return false;
        }
    }
    getPosicion(idEquipo) {
        for (let i = 0; i < this.#equipos.length; i++) {
            for (let j = 0; j < this.#equipos[i].length; i++) {
                return this.#equipos.indexOf(idEquipo, this.#equipos[i][j])//no detecta la id
            }
        }
    }
    getPorcentajeOcupacion() {
        let contador = 0;
        for (let i = 0; i < this.#equipos.length; i++) {
            for (let j = 0; j < this.#equipos[i].length; j++) {
                if (this.#equipos[i][j] == !null) {
                    contador++;//nunca suma no detecta ningun eqeuipo  
                }
            }
        }
        return (contador / this.#puestos) * 100
    }
    toString() {
        console.table(this.#equipos);
    }
}
let a1 = new Aula(4, 5, 6);
a1.toString();
let e1 = new Equipo("sdfsdfsd", true, 3);
e1.toString();
a1.activaEquipo(e1, 4, 5);
console.log(a1.getPosicion(e1.id));
console.log(a1.getPorcentajeOcupacion());
a1.toString();
