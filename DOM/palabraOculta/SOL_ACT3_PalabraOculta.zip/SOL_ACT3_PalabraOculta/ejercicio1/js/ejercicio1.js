/* global PalabraOculta */

window.addEventListener('load', cargaPagina);
var palabra = new PalabraOculta();


function cargaPagina() {
    //cargo la palabra desordenada en la caja de texto letras
    document.getElementById('letras').value = palabra.palabraDesordenada().toUpperCase();

    //añado los manejadores del campo de texto palabras y de los botones
    document.getElementById('palabra').addEventListener('keyup',aumentar);
    document.getElementById('nueva').addEventListener('click',reiniciar);
    document.getElementById('solucion').addEventListener('click',solucion);
    document.getElementById('finalizar').addEventListener('click',finalizar);
}

function aumentar(){
    document.getElementById('palabra').value = document.getElementById('palabra').value.toUpperCase();
    comprobar();
}

function habilita(id){
    document.getElementById(id).removeAttribute('disabled');
}

function deshabilita(id){
    document.getElementById(id).setAttribute('disabled','disabled');
}

function comprobar() {
    var textUsuario = document.getElementById('palabra');
    
    if (textUsuario.value === palabra.Seleccionada.toUpperCase()){
            let elemento = document.getElementById('resultado');
            elemento.innerHTML = "Has acertado la palabra " + textUsuario.value;
            elemento.className = "linea_formulario intentos";
            elemento.style.visibility = 'visible';

            deshabilita('solucion');
            habilita('nueva');
            deshabilita('palabra');

            palabra.Aciertos++;
    } 
}

function reiniciar(){
    document.getElementById('letras').value = palabra.palabraDesordenada().toUpperCase();

    deshabilita(this.id);
    habilita('solucion');
    habilita('palabra');

    document.getElementById('palabra').value = "";
    document.getElementById('resultado').style.visibility = 'hidden';
    
    palabra.Partidas++;
}

function solucion(){
    document.getElementById('palabra').value = "";

    deshabilita(this.id);
    deshabilita('palabra');
    habilita('nueva');

    var elemento = document.getElementById('resultado');
    elemento.innerHTML = "La palabra correcta es " + palabra.Seleccionada.toUpperCase();
    elemento.className = "linea_formulario info";
    elemento.style.visibility = 'visible';
}

function finalizar(){
    deshabilita(this.id);
    deshabilita('nueva');
    deshabilita('solucion');

    document.getElementById('letras').value = "";
    document.getElementById('palabra').value = "";

    deshabilita('letras');
    deshabilita('palabra');

    var porcentaje = document.getElementById('porcentaje');
    porcentaje.innerHTML += (palabra.Aciertos / palabra.Partidas * 100).toFixed(2) + "%";
    porcentaje.style.visibility = 'visible';
}
