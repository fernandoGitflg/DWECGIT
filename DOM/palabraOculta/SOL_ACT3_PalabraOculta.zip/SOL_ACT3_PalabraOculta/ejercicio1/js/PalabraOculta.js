class PalabraOculta{
    constructor(){
        this._listaPalabras = ["perro","gato","laredo","suelo","caballo","cerdo","zorro","cangrejo","santander","skills"];
        this._seleccionada = "";
        this._partidas=1;
        this._aciertos=0;
        }

get Seleccionada(){
    return this._seleccionada;
}

get Partidas(){
    return this._partidas;
}
set Partidas(partidas){
    this._partidas=partidas;
}
get Aciertos(){
    return this._aciertos;
}

set Aciertos(aciertos){
    this._aciertos=aciertos;
}

_generaIndiceAleatorio(){
    return Math.floor(Math.random() * this._listaPalabras.length);
}

_mezclar(){
    return Math.random() - 0.5;
}

palabraDesordenada (){
    var palabra = this._listaPalabras[this._generaIndiceAleatorio()];
    this._seleccionada = palabra;
    return palabra.split('').sort(this._mezclar).join('');
}
}