/* global PalabraOculta */

window.addEventListener('load', cargaPagina);

var palabra = new PalabraOculta();

function cargaPagina() {
    var arrayRadio = document.querySelectorAll('input[type="radio"]');
    for (var i = 0; i < arrayRadio.length; i++) {
        arrayRadio[i].addEventListener('click',dificultad);
        arrayRadio[i].id = "radio-" + (i + 1);
        arrayRadio[i].removeAttribute('checked');
    }
    deshabilita('letras');

    document.querySelector('#palabra').addEventListener('keyup',aumentar);
    document.querySelector('#nueva').addEventListener('click',reiniciar);
    document.querySelector('#solucion').addEventListener('click',solucion);
    document.querySelector('#finalizar').addEventListener('click',finalizar);
}

function aumentar(){
    document.querySelector('#palabra').value = document.querySelector('#palabra').value.toUpperCase();
    comprobar();
}

function habilita(id){
    document.getElementById(id).removeAttribute('disabled');
}

function deshabilita(id){
    document.getElementById(id).setAttribute('disabled','disabled');
}

function dificultad(){
    palabra.Dificultad=this.value;
    document.querySelectorAll('input[type="radio"]').forEach( function(i) {
               deshabilita(i.id);
            });
    
    fase();
}

function comprobar() {
    var textUsuario = document.getElementById('palabra');

    if (textUsuario.value === palabra.Seleccionada.toUpperCase()){
            let elemento = document.getElementById('resultado');
            elemento.innerHTML = "Has acertado la palabra " + textUsuario.value;
            elemento.className = "linea_formulario intentos";
            elemento.style.visibility = 'visible';
            deshabilita('solucion');
            habilita('nueva');
            deshabilita('palabra');
    
            palabra.Aciertos++;
            document.querySelectorAll('input[type="radio"]').forEach( function(i) {
                deshabilita(i.id);
            });
        } 
}

function reiniciar(){
    document.querySelectorAll('input[type="radio"]').forEach( function(i) {
            habilita(i.id);
            });
    document.getElementById('letras').value = "";
    document.getElementById('palabra').value = "";
    document.getElementById('resultado').style.visibility = 'hidden';
}

function solucion(){
   var textUsuario = document.getElementById('palabra');
    textUsuario.value = "";

    deshabilita(this.id);
    deshabilita('palabra');
    habilita('nueva');

    var elemento = document.getElementById('resultado');
    elemento.innerHTML = "La palabra correcta es " + palabra.Seleccionada.toUpperCase();
    elemento.className = "linea_formulario info";
    elemento.style.visibility = 'visible';
}

function finalizar(){
    deshabilita(this.id);
    deshabilita('nueva');
    deshabilita('solucion');

    document.getElementById('letras').value = "";
    document.getElementById('palabra').value = "";

    deshabilita('letras');
    deshabilita('palabra');

    var porcentaje = document.getElementById('porcentaje');
    porcentaje.innerHTML += (palabra.Aciertos / palabra.Partidas * 100).toFixed(2) + "%";
    document.getElementById('porcentaje').style.visibility = 'visible';

        /*Parte de cookies*/
        if (hayCookies()){
            if ((getCookie('mejorPartida') === null) || (parseInt(getCookie('mejorPartida')) < porcentaje.innerHTML)) {
                setCookieCaducidad('mejorPartida',porcentaje.innerHTML,31536000000);
                porcentaje.innerHTML += "<br />NUEVO RECORD!!!!";
            }
        }
}

function fase(){
    document.getElementById('letras').value = palabra.palabraDesordenada().toUpperCase();
    
    habilita('solucion');
    habilita('palabra');

    document.getElementById('palabra').value = "";
    document.getElementById('resultado').style.visibility = 'hidden';

    palabra.Partidas++;
}
