class PalabraOculta{
    constructor(){
        this._listaPalabras = {
            '4':["ramo","gato","moto","rabo","cola","luna","ruta","saco","robo","taza"],
            '6':["sabado","calido","callos","suelos","marchar","safari","matojo","batear","bienes","skills"],
            '8':["bandejas","pañuelos","castañas","dactilar","ebanista","novillos","jabalina","espumoso","pabellon","vacantes"]
        };
        this._dificultad = '4';
        this._seleccionada = "";
        this._partidas=1;
        this._aciertos=0;
        }

get ListaPalabras(){
    return this._listaPalabras;
}

get Seleccionada(){
    return this._seleccionada;
};

get Dificultad (){
    return this._dificultad;
}

set Dificultad (dificultad){
    this._dificultad=dificultad;
}
get Partidas(){
    return this._partidas;
}
set Partidas(partidas){
    this._partidas=partidas;
}
get Aciertos(){
    return this._aciertos;
}

set Aciertos(aciertos){
    this._aciertos=aciertos;
}

_generaIndiceAleatorio(){
    return Math.floor(Math.random() * this._listaPalabras[this._dificultad].length);
}

_mezclar(){
    return Math.random() - 0.5;
}

palabraDesordenada (){
    var palabra = this._listaPalabras[this._dificultad][this._generaIndiceAleatorio()];
    this._seleccionada = palabra;
    return palabra.split('').sort(this._mezclar).join('');
}
}
