import { Bailarin } from "./Bailarin.js";

export class Profesor extends Bailarin{
    constructor(nombre,apellidos,niveles){
        super(nombre,apellidos,niveles);
    }
}